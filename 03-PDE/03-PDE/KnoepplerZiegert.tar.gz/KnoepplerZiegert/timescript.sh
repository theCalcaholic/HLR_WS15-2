#!/bin/bash

echo $(hostname): $(date)
